# Neon Launcher

Launcher para Android con estética oscura y futurista, inspirado en Next Launcher 3D.

## Qué incluye
- Transiciones 3D entre páginas: Cubo, Cilindro, Carrusel y Profundidad.
- Fondo animado: estrellas, cuadrícula en perspectiva y parallax al deslizar.
- Reloj y fecha en cian neón.
- Dock con Teléfono, Mensajes, Buscador (central), Navegador y Cámara.
- Búsqueda rápida de apps (botón central del dock).
- Mantén pulsado un icono: Información de la app / Desinstalar.
- Mantén pulsado el reloj: cambiar efecto 3D y columnas (4 o 5).

## Cómo obtener el APK

### Opción A: Android Studio
1. Abre esta carpeta en Android Studio (Hedgehog o más reciente).
2. Espera a que sincronice Gradle.
3. Menú **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. El archivo queda en `app/build/outputs/apk/debug/app-debug.apk`.

### Opción B: GitHub Actions (sin instalar nada)
1. Crea un repositorio en GitHub y sube todo el contenido de esta carpeta.
2. Ve a la pestaña **Actions**; el flujo "Build APK" corre solo (o ejecútalo con "Run workflow").
3. Al terminar, descarga el artefacto **NeonLauncher-APK** (contiene `app-debug.apk`).

## Instalar
1. Pasa el APK al teléfono e instálalo (permite "instalar apps desconocidas").
2. Pulsa el botón Inicio y elige **Neon Launcher** → **Siempre**.
3. Para volver al launcher anterior: Ajustes → Apps → Apps predeterminadas → App de inicio.
