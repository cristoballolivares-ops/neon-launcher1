package com.neon.launcher

import android.app.AlertDialog
import android.app.Dialog
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import java.util.Date
import java.util.Locale

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var neonBg: NeonBackgroundView
    private lateinit var pager: ViewPager2
    private lateinit var dots: PageDotsView
    private lateinit var clock: TextView
    private lateinit var dateText: TextView
    private lateinit var dock: LinearLayout
    private lateinit var adapter: AppPagerAdapter

    private var apps: List<AppEntry> = emptyList()

    private val timeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            updateClock()
        }
    }

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadApps()
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        prefs = getSharedPreferences("neon", MODE_PRIVATE)

        buildUi()
        loadApps()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                pager.setCurrentItem(0, true)
            }
        })
        addOnNewIntentListener { pager.setCurrentItem(0, true) }
    }

    override fun onStart() {
        super.onStart()
        val timeFilter = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
        }
        ContextCompat.registerReceiver(this, timeReceiver, timeFilter, ContextCompat.RECEIVER_EXPORTED)

        val pkgFilter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, packageReceiver, pkgFilter, ContextCompat.RECEIVER_EXPORTED)
        updateClock()
    }

    override fun onStop() {
        unregisterReceiver(timeReceiver)
        unregisterReceiver(packageReceiver)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        neonBg.setRunning(true)
    }

    override fun onPause() {
        neonBg.setRunning(false)
        super.onPause()
    }

    // ---------------------------------------------------------------- interfaz

    private fun buildUi() {
        val root = FrameLayout(this).apply { clipChildren = false }

        neonBg = NeonBackgroundView(this)
        root.addView(neonBg, FrameLayout.LayoutParams(MATCH, MATCH))

        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
        }
        root.addView(column, FrameLayout.LayoutParams(MATCH, MATCH))

        // Cabecera: reloj y fecha (mantén pulsado para ajustes)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(20), 0, dp(4))
            setOnLongClickListener {
                showSettings()
                true
            }
        }
        clock = TextView(this).apply {
            textSize = 58f
            setTextColor(Palette.cyan)
            typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
            setShadowLayer(28f, 0f, 0f, Palette.cyan)
            includeFontPadding = false
        }
        dateText = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#C8CCFF"))
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            letterSpacing = 0.12f
        }
        header.addView(clock, LinearLayout.LayoutParams(WRAP, WRAP))
        header.addView(dateText, LinearLayout.LayoutParams(WRAP, WRAP))
        column.addView(header, LinearLayout.LayoutParams(MATCH, WRAP))

        // Páginas de apps
        adapter = AppPagerAdapter(
            onClick = { launch(it) },
            onLongClick = { showAppMenu(it) }
        )
        pager = ViewPager2(this).apply {
            adapter = this@MainActivity.adapter
            offscreenPageLimit = 1
            clipChildren = false
            (getChildAt(0) as RecyclerView).apply {
                clipChildren = false
                overScrollMode = View.OVER_SCROLL_NEVER
            }
            registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
                override fun onPageScrolled(
                    position: Int,
                    positionOffset: Float,
                    positionOffsetPixels: Int
                ) {
                    val p = position + positionOffset
                    neonBg.setParallax(p)
                    dots.setPosition(p)
                }
            })
        }
        applyEffect()
        column.addView(pager, LinearLayout.LayoutParams(MATCH, 0, 1f))

        // Indicador
        dots = PageDotsView(this)
        column.addView(
            dots,
            LinearLayout.LayoutParams(WRAP, dp(24)).apply { gravity = Gravity.CENTER_HORIZONTAL }
        )

        // Dock
        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#66101830"))
                cornerRadius = dp(28).toFloat()
                setStroke(dp(1), Color.parseColor("#5500E5FF"))
            }
        }
        column.addView(
            dock,
            LinearLayout.LayoutParams(MATCH, dp(76)).apply {
                setMargins(dp(16), dp(4), dp(16), dp(12))
            }
        )
        buildDock()

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            column.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }

        setContentView(root)
    }

    private fun buildDock() {
        dock.removeAllViews()

        val slots = listOf(
            resolveDockApp(Intent(Intent.ACTION_DIAL)),
            resolveDockApp(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:"))),
            null, // botón de búsqueda
            resolveDockApp(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))),
            resolveDockApp(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
        )

        for (slot in slots) {
            val wrapper = FrameLayout(this)
            dock.addView(wrapper, LinearLayout.LayoutParams(0, MATCH, 1f))

            if (slot == null) {
                val orb = ImageView(this).apply {
                    setImageResource(android.R.drawable.ic_menu_search)
                    setColorFilter(Palette.cyan)
                    setPadding(dp(13), dp(13), dp(13), dp(13))
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(Color.parseColor("#3300E5FF"))
                        setStroke(dp(2), Palette.cyan)
                    }
                    setOnClickListener { showSearch() }
                    pressable()
                }
                wrapper.addView(orb, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER))
            } else {
                val (entry, intent) = slot
                val icon = ImageView(this).apply {
                    setImageDrawable(entry.newIcon())
                    setOnClickListener {
                        try {
                            startActivity(intent)
                        } catch (e: Exception) {
                            Toast.makeText(this@MainActivity, "No se pudo abrir", Toast.LENGTH_SHORT).show()
                        }
                    }
                    pressable()
                }
                wrapper.addView(icon, FrameLayout.LayoutParams(dp(46), dp(46), Gravity.CENTER))
            }
        }
    }

    /** Busca la app predeterminada para un intent y devuelve su icono y el intent de lanzamiento. */
    private fun resolveDockApp(query: Intent): Pair<AppEntry, Intent>? {
        val pm = packageManager
        val ri = pm.resolveActivity(query, PackageManager.MATCH_DEFAULT_ONLY) ?: return null
        val pkg = ri.activityInfo?.packageName ?: return null
        if (pkg == "android" || pkg == packageName) return null
        val launchIntent = pm.getLaunchIntentForPackage(pkg) ?: return null
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val entry = AppEntry(
            ri.loadLabel(pm).toString(),
            ComponentName(pkg, ri.activityInfo.name),
            ri.loadIcon(pm)
        )
        return Pair(entry, launchIntent)
    }

    // ---------------------------------------------------------------- datos

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map {
                    AppEntry(
                        it.loadLabel(pm).toString(),
                        ComponentName(it.activityInfo.packageName, it.activityInfo.name),
                        it.loadIcon(pm)
                    )
                }
                .sortedBy { it.label.lowercase(Locale.getDefault()) }
            runOnUiThread {
                apps = list
                refreshPager()
            }
        }.start()
    }

    private fun refreshPager() {
        adapter.submit(apps, prefs.getInt("cols", 4))
        dots.count = adapter.itemCount
    }

    private fun updateClock() {
        val is24 = android.text.format.DateFormat.is24HourFormat(this)
        val timePattern = if (is24) "HH:mm" else "h:mm"
        val datePattern = android.text.format.DateFormat.getBestDateTimePattern(
            Locale.getDefault(), "EEEEdMMMM"
        )
        val now = Date()
        clock.text = java.text.SimpleDateFormat(timePattern, Locale.getDefault()).format(now)
        dateText.text = java.text.SimpleDateFormat(datePattern, Locale.getDefault())
            .format(now).uppercase(Locale.getDefault())
    }

    private fun applyEffect() {
        pager.setPageTransformer(Transformers.create(prefs.getInt("fx", Transformers.CUBE)))
    }

    // ---------------------------------------------------------------- acciones

    private fun launch(app: AppEntry) {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(app.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "No se pudo abrir ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAppMenu(app: AppEntry) {
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(app.label)
            .setItems(arrayOf("Información de la app", "Desinstalar")) { _, which ->
                val uri = Uri.parse("package:${app.packageName}")
                try {
                    when (which) {
                        0 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                        1 -> startActivity(Intent(Intent.ACTION_DELETE, uri))
                        else -> {}
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Acción no disponible", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun showSettings() {
        val items = arrayOf(
            "Efecto: Cubo 3D",
            "Efecto: Cilindro",
            "Efecto: Carrusel",
            "Efecto: Profundidad",
            "Columnas: 4",
            "Columnas: 5"
        )
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Neon Launcher")
            .setItems(items) { _, which ->
                when (which) {
                    in 0..3 -> {
                        prefs.edit().putInt("fx", which).apply()
                        applyEffect()
                    }
                    4 -> setCols(4)
                    5 -> setCols(5)
                    else -> {}
                }
            }
            .show()
    }

    private fun setCols(cols: Int) {
        prefs.edit().putInt("cols", cols).apply()
        refreshPager()
        pager.setCurrentItem(0, false)
    }

    // ---------------------------------------------------------------- búsqueda

    private fun showSearch() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(48), dp(16), dp(16))
        }

        val input = EditText(this).apply {
            hint = "Buscar apps…"
            setHintTextColor(Color.parseColor("#8000E5FF"))
            setTextColor(Color.WHITE)
            textSize = 18f
            maxLines = 1
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_DONE
            setPadding(dp(18), dp(12), dp(18), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#22FFFFFF"))
                cornerRadius = dp(26).toFloat()
                setStroke(dp(2), Palette.cyan)
            }
        }
        content.addView(input, LinearLayout.LayoutParams(MATCH, WRAP))

        var results: List<AppEntry> = apps
        val listAdapter = object : BaseAdapter() {
            override fun getCount(): Int = results.size
            override fun getItem(position: Int): Any = results[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val app = results[position]
                val row = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(8), dp(8), dp(8), dp(8))
                }
                val icon = ImageView(this@MainActivity).apply { setImageDrawable(app.newIcon()) }
                row.addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)))
                val label = TextView(this@MainActivity).apply {
                    text = app.label
                    textSize = 16f
                    setTextColor(Color.WHITE)
                    setPadding(dp(16), 0, 0, 0)
                }
                row.addView(label, LinearLayout.LayoutParams(WRAP, WRAP))
                return row
            }
        }

        val list = ListView(this).apply {
            divider = null
            this.adapter = listAdapter
            setOnItemClickListener { _, _, position, _ ->
                dialog.dismiss()
                launch(results[position])
            }
        }
        content.addView(
            list,
            LinearLayout.LayoutParams(MATCH, 0, 1f).apply { topMargin = dp(12) }
        )

        input.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString()?.trim().orEmpty().lowercase(Locale.getDefault())
                results = if (q.isEmpty()) apps
                else apps.filter { it.label.lowercase(Locale.getDefault()).contains(q) }
                listAdapter.notifyDataSetChanged()
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        input.setOnEditorActionListener { _, _, _ ->
            if (results.isNotEmpty()) {
                dialog.dismiss()
                launch(results[0])
            }
            true
        }

        dialog.setContentView(content)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.parseColor("#F205060F")))
            setLayout(MATCH, MATCH)
            setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or
                    WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            )
        }
        dialog.show()
        input.requestFocus()
    }
}
