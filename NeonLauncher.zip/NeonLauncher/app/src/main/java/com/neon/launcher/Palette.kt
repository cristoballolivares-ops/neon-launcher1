package com.neon.launcher

import android.graphics.Color
import android.graphics.drawable.Drawable
import android.view.MotionEvent
import android.view.View

object Palette {
    val cyan = Color.parseColor("#00E5FF")
    val magenta = Color.parseColor("#FF2BD6")
    val violet = Color.parseColor("#7C4DFF")
    val deep = Color.parseColor("#05060F")
}

data class AppEntry(
    val label: String,
    val component: android.content.ComponentName,
    val icon: Drawable
) {
    val packageName: String get() = component.packageName

    fun newIcon(): Drawable = icon.constantState?.newDrawable()?.mutate() ?: icon
}

/** Efecto de "rebote" al tocar un elemento. */
fun View.pressable() {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                v.animate().scaleX(0.86f).scaleY(0.86f).setDuration(80).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }
        false
    }
}
