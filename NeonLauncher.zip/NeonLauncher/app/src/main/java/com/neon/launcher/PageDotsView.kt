package com.neon.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import kotlin.math.abs
import kotlin.math.max

/** Indicador de páginas: el punto activo crece y brilla en cian mientras deslizas. */
class PageDotsView(context: Context) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Palette.cyan }
    private val d = resources.displayMetrics.density
    private var position = 0f

    var count: Int = 1
        set(value) {
            field = max(1, value)
            requestLayout()
            invalidate()
        }

    fun setPosition(p: Float) {
        position = p
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = (count * 16 * d + 24 * d).toInt()
        val h = (24 * d).toInt()
        setMeasuredDimension(resolveSize(w, widthMeasureSpec), resolveSize(h, heightMeasureSpec))
    }

    override fun onDraw(canvas: Canvas) {
        val spacing = 16 * d
        val startX = (width - (count - 1) * spacing) / 2f
        for (i in 0 until count) {
            val c = max(0f, 1f - abs(i - position))
            paint.alpha = (90 + 165 * c).toInt()
            val r = (2.5f + 2.5f * c) * d
            canvas.drawCircle(startX + i * spacing, height / 2f, r, paint)
        }
    }
}
