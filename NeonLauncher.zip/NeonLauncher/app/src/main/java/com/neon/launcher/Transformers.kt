package com.neon.launcher

import android.view.View
import androidx.viewpager2.widget.ViewPager2
import kotlin.math.abs

/** Transiciones 3D entre páginas (inspiradas en Next Launcher 3D). */
object Transformers {
    const val CUBE = 0
    const val CYLINDER = 1
    const val CAROUSEL = 2
    const val DEPTH = 3

    private fun reset(page: View) {
        page.alpha = 1f
        page.scaleX = 1f
        page.scaleY = 1f
        page.rotationY = 0f
        page.translationX = 0f
        page.translationZ = 0f
        page.pivotX = page.width / 2f
        page.pivotY = page.height / 2f
    }

    fun create(mode: Int): ViewPager2.PageTransformer = when (mode) {
        CYLINDER -> ViewPager2.PageTransformer { page, position ->
            reset(page)
            page.cameraDistance = page.width * 10f
            if (abs(position) >= 1.2f) {
                page.alpha = 0f
            } else {
                page.rotationY = position * 55f
                page.translationX = -position * page.width * 0.2f
                val s = 1f - 0.15f * abs(position)
                page.scaleX = s
                page.scaleY = s
                page.alpha = 1f - 0.5f * abs(position)
            }
        }

        CAROUSEL -> ViewPager2.PageTransformer { page, position ->
            reset(page)
            page.cameraDistance = page.width * 10f
            if (abs(position) >= 1.5f) {
                page.alpha = 0f
            } else {
                page.rotationY = position * 40f
                page.translationX = -position * page.width * 0.28f
                val s = 1f - 0.22f * abs(position)
                page.scaleX = s
                page.scaleY = s
                page.alpha = 1f - 0.55f * abs(position)
                page.translationZ = -abs(position)
            }
        }

        DEPTH -> ViewPager2.PageTransformer { page, position ->
            reset(page)
            when {
                position <= -1f || position >= 1f -> page.alpha = 0f
                position <= 0f -> {
                    page.alpha = 1f
                    page.translationZ = 1f
                }
                else -> {
                    page.alpha = 1f - position
                    page.translationX = -position * page.width
                    val s = 0.75f + 0.25f * (1f - abs(position))
                    page.scaleX = s
                    page.scaleY = s
                    page.translationZ = -1f
                }
            }
        }

        else -> ViewPager2.PageTransformer { page, position ->
            // Cubo 3D
            reset(page)
            page.cameraDistance = page.width * 12f
            if (position <= -1f || position >= 1f) {
                page.alpha = 0f
            } else {
                page.pivotX = if (position < 0f) page.width.toFloat() else 0f
                page.pivotY = page.height * 0.5f
                page.rotationY = 90f * position
            }
        }
    }
}
