package com.neon.launcher

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.sin
import java.util.Random

/**
 * Fondo animado: degradado espacial, estrellas parpadeantes y una cuadrícula
 * en perspectiva que avanza lentamente (estilo synthwave). Reacciona al
 * desplazamiento de las páginas con un efecto parallax.
 */
class NeonBackgroundView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val bgPaint = Paint()
    private val glowA = Paint()
    private val glowB = Paint()
    private val starPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * resources.displayMetrics.density
        color = Palette.cyan
    }
    private val horizonPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f * resources.displayMetrics.density
        color = Palette.magenta
    }

    private var phase = 0f
    private var parallax = 0f

    private val starCount = 90
    private val starX = FloatArray(starCount)
    private val starY = FloatArray(starCount)
    private val starR = FloatArray(starCount)
    private val starT = FloatArray(starCount)

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 7000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    init {
        val rnd = Random(7)
        for (i in 0 until starCount) {
            starX[i] = rnd.nextFloat()
            starY[i] = rnd.nextFloat() * 0.62f
            starR[i] = 0.5f + rnd.nextFloat() * 1.3f
            starT[i] = rnd.nextFloat()
        }
    }

    fun setParallax(value: Float) {
        parallax = value
        if (!animator.isRunning) invalidate()
    }

    fun setRunning(run: Boolean) {
        if (run) {
            if (!animator.isRunning) animator.start()
        } else {
            animator.cancel()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        setRunning(true)
    }

    override fun onDetachedFromWindow() {
        setRunning(false)
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        bgPaint.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            intArrayOf(
                Color.parseColor("#03040C"),
                Color.parseColor("#0A0B26"),
                Color.parseColor("#1A0B36")
            ),
            floatArrayOf(0f, 0.62f, 1f),
            Shader.TileMode.CLAMP
        )
        glowA.shader = RadialGradient(
            w * 0.85f, h * 0.16f, w * 0.75f,
            Color.parseColor("#55FF2BD6"), Color.parseColor("#00FF2BD6"),
            Shader.TileMode.CLAMP
        )
        glowB.shader = RadialGradient(
            w * 0.05f, h * 0.72f, w * 0.8f,
            Color.parseColor("#4400E5FF"), Color.parseColor("#0000E5FF"),
            Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return

        canvas.drawRect(0f, 0f, w, h, bgPaint)
        canvas.drawRect(0f, 0f, w, h, glowA)
        canvas.drawRect(0f, 0f, w, h, glowB)

        // Estrellas
        val shift = -parallax * w * 0.04f
        for (i in 0 until starCount) {
            val tw = 0.5f + 0.5f * sin(2.0 * PI * (phase * 2f + starT[i])).toFloat()
            starPaint.alpha = (60 + 160 * tw).toInt()
            var x = starX[i] * w + shift
            x = ((x % w) + w) % w
            canvas.drawCircle(x, starY[i] * h, starR[i] * resources.displayMetrics.density, starPaint)
        }

        // Cuadrícula en perspectiva
        val horizon = h * 0.66f
        val px = -parallax * w * 0.18f
        val lines = 14
        for (i in 0 until lines) {
            val t = (i + phase) / lines
            val y = horizon + (h - horizon) * t * t
            gridPaint.alpha = (200 * t).toInt().coerceIn(0, 255)
            canvas.drawLine(0f, y, w, y, gridPaint)
        }
        val spacing = w * 0.22f
        gridPaint.alpha = 90
        for (k in -12..12) {
            val xb = w / 2f + px + k * spacing
            val xh = w / 2f + px * 0.3f + k * spacing * 0.06f
            canvas.drawLine(xh, horizon, xb, h, gridPaint)
        }

        // Línea de horizonte
        horizonPaint.alpha = 200
        canvas.drawLine(0f, horizon, w, horizon, horizonPaint)
    }
}
